// fileUpload.page.ts
class FileUploadPage {
  get fileInput() { return $('#file-upload'); }
  get uploadButton() { return $('#file-submit'); }
  get uploadedFiles() { return $('#uploaded-files'); }

  async open(): Promise<void> {
    await browser.url('https://the-internet.herokuapp.com/upload');
  }

  async uploadFile(filePath: string): Promise<void> {
    await this.fileInput.setValue(filePath);
    await this.uploadButton.click();
  }

  async getUploadedFileName(): Promise<string> {
    return this.uploadedFiles.getText();
  }
}

export default new FileUploadPage();
