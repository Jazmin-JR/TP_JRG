// form.steps.ts
import { Given, When, Then } from '@wdio/cucumber-framework';
import FormPage from '../page-objects/form.page';
import ThankYouPage from '../page-objects/thankYou.page';

Given('El usuario está en la página formulario', async () => {
  await FormPage.open();
});

When('El usuario rellena y envía el formulario con nombre {string}, apellido {string} y título {string}', async (firstName, lastName, jobTitle) => {
  await FormPage.submitForm(firstName, lastName, jobTitle);
});

Then('El usuario debería ser redirigido a la página notificacion de envío de formulario', async () => {
  const expectedMessage = 'Formulario enviado exitosamente, Gracias!!';
  const actualMessage = await ThankYouPage.getMessageText();

  await expect(actualMessage).toContain(expectedMessage);
});


