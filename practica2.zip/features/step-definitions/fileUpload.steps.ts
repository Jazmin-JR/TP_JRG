// fileUpload.steps.ts
import { Given, When, Then } from '@wdio/cucumber-framework';
import FileUploadPage from '../page-objects/fileUpload.page';
import path from 'path';

Given('El usuario está en la página de carga de archivos', async () => {
  await FileUploadPage.open();
});

When('El usuario carga el archivo {string}', async (fileName: string) => {
  const filePath = path.join(__dirname, fileName); 
  await FileUploadPage.uploadFile(filePath);
});

Then('El nombre del archivo cargado {string} debe mostrarse', async (expectedFileName: string) => {
  const uploadedFileName = await FileUploadPage.getUploadedFileName();
  await expect(uploadedFileName).toEqual(expectedFileName);
});
