class ThankYouPage {
    get thankYouMessage() { return $('.alert.alert-success'); }
  
    async getMessageText(): Promise<string> {
      return this.thankYouMessage.getText();
    }
  }
  
  export default new ThankYouPage();
  