// form.page.ts
class FormPage {
  get firstNameInput() { return $('#first-name'); }
  get lastNameInput() { return $('#last-name'); }
  get jobTitleInput() { return $('#job-title'); }
  get submitButton() { return $('.btn.btn-lg.btn-primary'); }

  async open(): Promise<void> {
    await browser.url('https://formy-project.herokuapp.com/form');
  }

  async submitForm(firstName: string, lastName: string, jobTitle: string): Promise<void> {
    await this.firstNameInput.setValue(firstName);
    await this.lastNameInput.setValue(lastName);
    await this.jobTitleInput.setValue(jobTitle);
    await this.submitButton.click();
  }
}

export default new FormPage();
